package com.acad.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.MaterialTheme.typography
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.acad.calculator.ui.theme.CalculatorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculatorTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    CalculatorApp()
                }
            }
        }
    }
}

@Composable
fun CalculatorApp() {

    val specialButtonColor = colorResource(id = R.color.orange)
    val buttons = listOf<List<ButtonCalc>>(
        listOf(ButtonCalc(label = "C", color = specialButtonColor), ButtonCalc(label = "<", color = specialButtonColor), ButtonCalc(label = "%", color = specialButtonColor ), ButtonCalc("/", color = specialButtonColor)),
        listOf(ButtonCalc(label = "7", Color.White), ButtonCalc(label = "8", Color.White), ButtonCalc(label = "9", Color.White), ButtonCalc(label = "x", color = specialButtonColor)),
        listOf(ButtonCalc(label = "4", Color.White), ButtonCalc(label = "5", Color.White), ButtonCalc(label = "6", Color.White), ButtonCalc(label = "-", color = specialButtonColor)),
        listOf(ButtonCalc(label = "1", Color.White), ButtonCalc(label = "2", Color.White), ButtonCalc(label = "3", Color.White), ButtonCalc(label = "+", color = specialButtonColor)),
        listOf(ButtonCalc(label = "0", Color.White), ButtonCalc(label = ".", Color.White),  ButtonCalc(label = "=", Color.White)),
    )
    var scrollState by remember { mutableStateOf(ScrollState(0)) }
    var display by remember { mutableStateOf("" ) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(20.dp)

    ) {

        Box (
            contentAlignment = Alignment.BottomCenter,
            modifier = Modifier
                .weight(1f)
        ){
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentWidth(),
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    text = display,
                    color= Color.White,
                    textAlign = TextAlign.End,
                    style = typography.h2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState))


                Divider(color = Color.Gray, modifier = Modifier.padding(top = 30.dp, bottom = 30.dp) )
                buttons.forEach { row ->

                        Row(
                            modifier = Modifier
                            .fillMaxWidth(),

                            horizontalArrangement = Arrangement.spacedBy(0.dp) ) {
                            row.forEach { (label, color) ->
                                val colorButton = if (label != "=") Color.Black else colorResource(id = R.color.orange)
                                val weightButton = if (label != "0") 1f else 2f

                                Button(
                                    onClick = {

                                        when(label) {
                                            "C" -> { display = "" }
                                            "=" -> { display = "= result" }
                                            "<" -> {
                                                if(display.isNotBlank())
                                                    display = display.removeRange(display.length - 1, display.length)
                                            }
                                            else -> { display += label }
                                        }
                                    } ,
                                    modifier = Modifier
                                        .weight(weight = weightButton)
                                        .padding(top = 10.dp, bottom = 10.dp)
                                        .wrapContentSize()
                                        .align(CenterVertically)
                                        .aspectRatio(1f)
                                        .clip(CircleShape),
//                                    shape = RoundedCornerShape(100),
                                    colors = ButtonDefaults.buttonColors(backgroundColor = colorButton)

                                ) {
                                    Text(
                                        text = label,
                                        color = color,
                                        modifier = Modifier
//                                            .padding(top = 15.dp, bottom = 15.dp)
                                            .fillMaxWidth(),
                                        textAlign = TextAlign.Center,
                                        style = typography.h4)

                                }
                            }
                        }
                }
            }
        }
    }
}

data class  ButtonCalc(val label: String, val color: Color)

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    CalculatorTheme {
        CalculatorApp()
    }
}