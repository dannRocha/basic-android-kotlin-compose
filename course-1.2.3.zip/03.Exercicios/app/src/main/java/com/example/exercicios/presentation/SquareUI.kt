package com.example.exercicios.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.exercicios.R

/**
 *
 * Solution:
 * https://github.com/google-developer-training/basic-android-kotlin-compose-training-practice-problems/blob/main/Unit%201/Pathway%203/ComposeQuadrant/app/src/main/java/com/example/composequadrant/MainActivity.kt
 */

@Composable
fun SquareUI() {
    Box(
        modifier = Modifier
            .background(Color.Magenta)
            .fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .wrapContentSize()
                .fillMaxSize()

        ) {

            Row(
                modifier = Modifier
                    .background(Color.Gray)
                    .wrapContentWidth()
                    .fillMaxHeight(0.5f)
                    .fillMaxWidth()
            ) {
                Box(modifier = Modifier
                    .background(Color.Green)
                    .fillMaxWidth(0.5f)
                    .wrapContentHeight()
                    .fillMaxHeight()
                ){
                    Column(
                        modifier = Modifier
                            .wrapContentSize()
                            .padding(16.dp)
                            .align( Alignment.Center)
                    ) {
                        SimpleCardText(
                            title = stringResource(R.string.first_title),
                            subtitle = stringResource(R.string.first_description))
                    }
                }
                Box(modifier = Modifier
                    .background(Color.Yellow)
                    .fillMaxWidth(1f)
                    .wrapContentHeight()
                    .fillMaxHeight()
                ){
                    Column(
                        modifier = Modifier
                            .wrapContentSize()
                            .padding(16.dp)
                            .align( Alignment.Center)
                    ) {
                        SimpleCardText(
                            title = stringResource(R.string.second_title),
                            subtitle = stringResource(R.string.second_description))
                    }
                }
            }

            Row(
                modifier = Modifier
                    .background(Color.Gray)
                    .wrapContentWidth()
                    .fillMaxHeight(1f)
                    .fillMaxWidth()
            ) {
                Box(modifier = Modifier
                    .background(Color.Cyan)
                    .fillMaxWidth(.5f)
                    .wrapContentHeight()
                    .fillMaxHeight()
                ){
                    Column(
                        modifier = Modifier
                            .wrapContentSize()
                            .padding(16.dp)
                            .align( Alignment.Center)
                    ) {
                        SimpleCardText(
                            title = stringResource(R.string.third_title),
                            subtitle = stringResource(R.string.third_description))
                    }
                }

                Box(modifier = Modifier
                    .background(Color.LightGray)
                    .fillMaxWidth(1f)
                    .wrapContentHeight()
                    .fillMaxHeight()
                ) {
                    Column(
                        modifier = Modifier
                            .wrapContentSize()
                            .padding(16.dp)
                            .align( Alignment.Center)
                    ) {
                        SimpleCardText(
                            title = stringResource(R.string.fourth_title),
                            subtitle = stringResource(R.string.fourth_description))
                    }
                }
            }

        }
    }
}

@Composable
fun SimpleCardText(title: String, subtitle: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .wrapContentWidth()
            .fillMaxWidth()
            .padding(bottom = 16.dp)
    )
    Text(
        text = subtitle,
        textAlign = TextAlign.Justify
    )

}

@Composable
@Preview(showBackground = true)
fun PreviewSquareUI() {
    SquareUI()
}