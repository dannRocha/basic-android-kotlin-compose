# Business Card

Desafio UI basica curso de android google


## Screenshot
![](screenshot/screenshot.jpg)

* [Demo](https://www.linkedin.com/posts/dann-rocha_androidbasics-mobile-android-activity-7002044581953302528-jSBU?utm_source=share&utm_medium=member_desktop)"