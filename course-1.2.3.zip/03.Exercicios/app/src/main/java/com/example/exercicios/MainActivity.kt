package com.example.exercicios

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.exercicios.presentation.JetpackTutorial
import com.example.exercicios.presentation.SquareUI
import com.example.exercicios.presentation.TaskManager
import com.example.exercicios.ui.theme.ExerciciosTheme

class MainActivity : ComponentActivity() {
    private val jetpackUI = 1
    private val taskManagerUI = 2
    private val squareUI = 3

    private val uiIndex = mutableStateOf(1);

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ExerciciosTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background,
                ) {
                    Main(this.baseContext)
                }
            }
        }
    }

    @Composable
    fun Main(baseContext: Context?) {
        val  scrollState = rememberScrollState()
        LaunchedEffect(Unit) { scrollState.animateScrollTo(100) }

        Column {
            Row(modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
            ) {
                Button(
                    onClick = { uiIndex.value =  jetpackUI },
                    modifier = Modifier
                        .wrapContentSize()
                        .fillMaxWidth(.33f)
                        .fillMaxHeight()
                ) {
                    Text("JetpackUI")
                }
                Button(
                    onClick = { uiIndex.value =  taskManagerUI },
                    modifier = Modifier
                        .wrapContentSize()
                        .fillMaxWidth(.55f)
                        .fillMaxHeight()
                ) {
                    Text("TaskMangerUI")
                }
                Button(onClick = {
                    uiIndex.value =  squareUI

                    val text = "Hello toast!"
                    val duration = Toast.LENGTH_SHORT


                    val toast = Toast.makeText(baseContext, text, duration)
                    toast.show()
                },
                    modifier = Modifier
                        .wrapContentSize()
                        .fillMaxWidth(1f)
                        .fillMaxHeight()
                ) {
                    Text("SquareUI")
                }

            }


            if(uiIndex.value == jetpackUI) {
                JetpackTutorial(scrollState)
            }
            if(uiIndex.value == taskManagerUI) {
                TaskManager()
            }
            if(uiIndex.value == squareUI) {
                SquareUI()
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun Preview() {
        ExerciciosTheme {
            // A surface container using the 'background' color from the theme
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colors.background,
            ) {
//                uiIndex.value = taskManagerUI
                Main(this.baseContext)
            }
        }
    }
}

