package com.example.greettingcard

import android.os.Bundle
import android.text.Layout.Alignment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.greettingcard.ui.theme.GreettingCardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GreettingCardTheme {
                // A surface container using the 'background' color from the theme
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
                    Greeting("Daniel")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String) {
    Surface(color = Color.Blue, border = BorderStroke(2.dp, Color.Red), modifier = Modifier.fillMaxSize()) {
        Column {
            Text(
                text = "Meu nome é $name!",
                color = Color.Red,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { /*TODO*/ },
                modifier = Modifier.align(CenterHorizontally)) {
                Text(text = "Clique aki")

            }
        }

    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    GreettingCardTheme {
        Greeting("Daniel Rocha!")
    }
}