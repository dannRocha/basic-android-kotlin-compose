package com.example.exercicios.presentation

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Alignment.Companion.End
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.exercicios.R

/**
 * Solution
 * https://github.com/google-developer-training/basic-android-kotlin-compose-training-practice-problems/blob/main/Unit%201/Pathway%203/TaskCompleted/app/src/main/java/com/example/taskcompleted/MainActivity.kt
 */
@Composable
fun TaskManager() {
    val teskImage = painterResource(id = R.drawable.ic_task_completed)

    Box(
        Modifier
            .fillMaxSize()
    ) {
      Column(
        Modifier
            .align( alignment = Alignment.Center)
      ) {
          Image(painter = teskImage, contentDescription = null)
          Text(
              text = stringResource(R.string.all_task_completed),
              fontSize = 24.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier
                  .padding(top = 24.dp, bottom = 8.dp)
          )
          Text(
              text = stringResource(R.string.nice_work),
              fontSize = 16.sp,
              modifier = Modifier
                  .wrapContentWidth()
                  .align(alignment = CenterHorizontally)
          )
      }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewTaskManager() {
    TaskManager()
}