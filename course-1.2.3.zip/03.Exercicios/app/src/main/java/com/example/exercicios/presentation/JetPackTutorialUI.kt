package com.example.exercicios.presentation

import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.exercicios.R

/**
 * solution:
 * https://github.com/google-developer-training/basic-android-kotlin-compose-training-practice-problems/blob/main/Unit%201/Pathway%203/ComposeArticle/app/src/main/java/com/example/composearticle/MainActivity.kt
 */
@Composable
fun JetpackTutorial(scrollStage: ScrollState = rememberScrollState()) {
    val image = painterResource(id = R.drawable.bg_compose_background)

    Column(
        modifier = Modifier
            .verticalScroll(scrollStage)
    ) {
        for (i in 1..20) {
            Image(
                painter = image,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
            )
            ArticleSection(
                title = stringResource(R.string.jetpack_tutorial_title),
                subtitle = stringResource(R.string.jetpack_tutorial_abstract),
                body = stringResource(R.string.jetpack_tutorial_body)
            )
        }
    }
}

@Composable
fun ContainerRow(content: @Composable RowScope.() -> Unit) {
    Row(
        content =  content ,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp)
    )
}

@Composable
fun ArticleSection(title: String, subtitle: String, body: String) {
    ContainerRow {
        TitleDefault(text = title)
    }
    ContainerRow {
        TextDefault(text = stringResource(R.string.jetpack_tutorial_abstract))
    }
    ContainerRow {
        TextDefault(text = stringResource(R.string.jetpack_tutorial_body))
    }
}
@Composable
fun TitleDefault(text: String) {
    Text(
        text = text,
        fontSize = 24.sp
    )
}

@Composable
fun TextDefault(text: String) {
    Text(
        text = text,
        fontSize = 16.sp,
        textAlign = TextAlign.Justify
    )
}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    JetpackTutorial()
}