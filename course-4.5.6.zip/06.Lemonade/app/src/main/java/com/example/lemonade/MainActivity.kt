package com.example.lemonade

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lemonade.ui.theme.LemonadeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LemonadeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    LemonadeApp()
                }
            }
        }
    }
}

@Composable
fun LemonadeApp() {
    val lemonadeStateList = listOf(
        LemonadeState(label = stringResource(R.string.label_lemon_tree), R.drawable.lemon_tree),
        LemonadeState(label = stringResource(R.string.label_lemon_squeeze), R.drawable.lemon_squeeze),
        LemonadeState(label = stringResource(R.string.label_lemon_drink), R.drawable.lemon_drink),
        LemonadeState(label = stringResource(R.string.label_lemon_restart), R.drawable.lemon_restart),
    )

    var lemonadeStateIndex by remember { mutableStateOf(0) }
    var lemonadeState by remember { mutableStateOf(lemonadeStateList[lemonadeStateIndex]) }
    var timesSqueeze by remember { mutableStateOf((2..4).random()) }
    var squeezeCount by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .wrapContentSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LemonadeFrame(lemonadeState = lemonadeState) {
            val lemonadeStateSqueeze = 1
            if( squeezeCount != timesSqueeze && lemonadeStateIndex == lemonadeStateSqueeze) {
                squeezeCount++
            }
            else {
                squeezeCount = 0
                timesSqueeze = (2..4).random()

                lemonadeStateIndex = ++lemonadeStateIndex % lemonadeStateList.size
                lemonadeState = lemonadeStateList[lemonadeStateIndex]
            }
        }
    }
}

@Composable
fun LemonadeFrame(lemonadeState: LemonadeState, onClick: () -> Unit) {

    Text(
        text = lemonadeState.label,
        fontSize = 18.sp)
    Spacer(Modifier.height(16.dp))
    Image(
        painter = painterResource(id = lemonadeState.image),
        contentDescription = null,
        modifier = Modifier.clickable { onClick() })
}

data class LemonadeState(
    val label: String,
    val image: Int) {
}

@Preview(showBackground = true)
@Composable
fun PreviewLemonade() {
    LemonadeTheme {
        LemonadeApp()
    }
}
