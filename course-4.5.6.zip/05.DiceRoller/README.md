# Dice Roller
Google's Android Training. Custom application

# Screenshot:
<p align="center">
  <img src="screenshot/dice.jpg" width="180px" />
</p>